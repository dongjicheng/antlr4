package open.module.module;

import java.module.moduleTest;
import java.open.openTest;

class module {
	java.module.moduleTest module(){
		return module();
	}
}
class open {
	java.module.moduleTest module(){
		return module();
	}
}
public class to {
	to with = null;
  public to to() {
	  return with.to();
  }
  public to to() {
	  to exports = null;
	  to provides = null;
	  to requires = null;
	  to uses = null;
	  return to();
  }
 
}
