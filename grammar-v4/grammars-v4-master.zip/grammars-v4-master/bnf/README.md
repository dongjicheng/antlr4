# BNF Grammar

An ANTLR4 grammar for [BNF](http://en.wikipedia.org/wiki/Backus%E2%80%93Naur_Form).