#B Grammar

# Summary

A first attempt at a grammar for the programming language [B](https://en.wikipedia.org/wiki/B_(programming_language))


