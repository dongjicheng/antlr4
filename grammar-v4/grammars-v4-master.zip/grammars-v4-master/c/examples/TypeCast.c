f()
{
	a1 = (int)(b1);
	a2 = (CustomType)(b2);
	a3 = (CustomType *)(b3);
	a4 = (CustomType **)(b4);
	a5 = b5();
}
